<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Détail de la session')); ?>

            </h2>
            <a href="<?php echo e(route('coach.sessions.index')); ?>" class="text-sm text-indigo-600 hover:text-indigo-900">
                &larr; Retour au planning
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex items-start justify-between mb-6">
                        <div>
                            <h3 class="text-lg font-semibold"><?php echo e($session->courseClass->name ?? 'Classe supprimée'); ?></h3>
                            <?php if($session->courseClass?->level): ?>
                                <p class="text-sm text-gray-500">
                                    <?php echo e($session->courseClass->level->program->name ?? ''); ?>

                                    <?php if($session->courseClass->level->program): ?> &middot; <?php endif; ?>
                                    <?php echo e($session->courseClass->level->name); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <?php
                            $badges = [
                                'scheduled' => ['Prévue', 'bg-blue-100 text-blue-800'],
                                'completed' => ['Effectuée', 'bg-green-100 text-green-800'],
                                'validated' => ['Validée', 'bg-emerald-100 text-emerald-800'],
                                'cancelled' => ['Annulée', 'bg-red-100 text-red-800'],
                            ];
                            [$label, $classes] = $badges[$session->status] ?? [$session->status, 'bg-gray-100 text-gray-800'];
                        ?>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($classes); ?>"><?php echo e($label); ?></span>
                    </div>

                    <dl class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4 text-sm">
                        <div>
                            <dt class="font-medium text-gray-500">Date</dt>
                            <dd class="text-gray-900"><?php echo e($session->start_time->format('d/m/Y')); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Horaires</dt>
                            <dd class="text-gray-900"><?php echo e($session->start_time->format('H:i')); ?> &ndash; <?php echo e($session->end_time->format('H:i')); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Durée</dt>
                            <dd class="text-gray-900"><?php echo e($session->start_time->diffInMinutes($session->end_time)); ?> min</dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Type d'intervention</dt>
                            <dd class="text-gray-900"><?php echo e($session->intervention_type ?? '—'); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Rémunération</dt>
                            <dd class="text-gray-900"><?php echo e(number_format($session->amount, 0, ',', ' ')); ?></dd>
                        </div>
                        <?php if($session->online_link): ?>
                            <div class="sm:col-span-2 lg:col-span-3">
                                <dt class="font-medium text-gray-500">Lien de la séance</dt>
                                <dd>
                                    <a href="<?php echo e($session->online_link); ?>" target="_blank" rel="noopener" class="text-indigo-600 hover:underline break-all"><?php echo e($session->online_link); ?></a>
                                </dd>
                            </div>
                        <?php endif; ?>
                    </dl>
                </div>
            </div>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-4">Rapport de séance</h3>

                    <?php if($session->sessionReport): ?>
                        <p class="text-xs text-gray-500 mb-4">
                            Soumis le <?php echo e($session->sessionReport->created_at->format('d/m/Y à H:i')); ?>

                        </p>
                        <div class="space-y-4">
                            <div>
                                <h4 class="text-sm font-medium text-gray-500 mb-1">Résumé de la progression</h4>
                                <div class="text-sm text-gray-900 whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 leading-relaxed"><?php echo e($session->sessionReport->progress); ?></div>
                            </div>
                            <?php if($session->sessionReport->observations): ?>
                                <div>
                                    <h4 class="text-sm font-medium text-gray-500 mb-1">Observations</h4>
                                    <div class="text-sm text-gray-900 whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 leading-relaxed"><?php echo e($session->sessionReport->observations); ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic mb-4">Aucun rapport n'a encore été rédigé pour cette séance.</p>
                        <p class="text-sm text-gray-600 mb-4">
                            Saisie possible de
                            <span class="font-medium"><?php echo e($session->debutFenetreRapport()->format('d/m/Y H:i')); ?></span>
                            à
                            <span class="font-medium"><?php echo e($session->finFenetreRapport()->format('H:i')); ?></span>
                            (<?php echo e(\App\Models\ClassSession::MARGE_RAPPORT_MINUTES); ?> min avant et après la séance).
                        </p>
                        <?php if($session->fenetreRapportOuverte()): ?>
                            <a href="<?php echo e(route('coach.sessions.report.create', $session)); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium hover:bg-indigo-700">
                                Rédiger le rapport
                            </a>
                        <?php else: ?>
                            <span class="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-500 rounded-md text-sm font-medium cursor-not-allowed">
                                Rédaction fermée
                            </span>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <?php
                        $presents = $session->attendances->where('is_present', true)->count();
                        $total = $session->attendances->count();
                    ?>
                    <h3 class="text-lg font-semibold mb-4">
                        Présences
                        <?php if($total > 0): ?>
                            <span class="text-sm font-normal text-gray-500">(<?php echo e($presents); ?>/<?php echo e($total); ?>)</span>
                        <?php endif; ?>
                    </h3>

                    <?php if($total > 0): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse text-sm">
                                <thead>
                                    <tr>
                                        <th class="border-b py-2 px-4">Apprenant</th>
                                        <th class="border-b py-2 px-4 text-center">Présence</th>
                                        <th class="border-b py-2 px-4">Retour de l'apprenant</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $session->attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="border-b py-3 px-4 font-medium"><?php echo e($attendance->student->name ?? 'Apprenant supprimé'); ?></td>
                                            <td class="border-b py-3 px-4 text-center">
                                                <?php if($attendance->is_present): ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Présent</span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Absent</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="border-b py-3 px-4 text-gray-700">
                                                <?php if($attendance->feedback): ?>
                                                    <?php if($attendance->rating): ?>
                                                        <div class="text-amber-500 mb-1"><?php echo e(str_repeat('★', (int) $attendance->rating)); ?><?php echo e(str_repeat('☆', max(0, 5 - (int) $attendance->rating))); ?></div>
                                                    <?php endif; ?>
                                                    <div class="whitespace-pre-wrap break-words"><?php echo e($attendance->feedback); ?></div>
                                                <?php else: ?>
                                                    <span class="text-gray-400">—</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Les présences seront enregistrées avec le rapport de séance.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/coach/sessions/show.blade.php ENDPATH**/ ?>