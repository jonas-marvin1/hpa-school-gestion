<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'options' => [],
    'selected' => null,
    'placeholder' => 'Rechercher...',
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'options' => [],
    'selected' => null,
    'placeholder' => 'Rechercher...',
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $selectedLabel = $selected !== null && isset($options[$selected]) ? $options[$selected] : '';
?>

<div
    x-data="{
        open: false,
        search: <?php echo \Illuminate\Support\Js::from($selectedLabel)->toHtml() ?>,
        selectedId: <?php echo \Illuminate\Support\Js::from($selected ?? '')->toHtml() ?>,
        options: <?php echo \Illuminate\Support\Js::from($options)->toHtml() ?>,
        get filtered() {
            if (!this.search || this.search === this.selectedLabel()) return this.options;
            const q = this.search.toLowerCase();
            return Object.fromEntries(Object.entries(this.options).filter(([id, label]) => label.toLowerCase().includes(q)));
        },
        selectedLabel() {
            return this.options[this.selectedId] ?? '';
        },
        select(id, label) {
            this.selectedId = id;
            this.search = label;
            this.open = false;
        }
    }"
    @click.outside="open = false"
    class="relative"
>
    <input
        type="text"
        x-model="search"
        @focus="open = true"
        @input="open = true; selectedId = ''"
        autocomplete="off"
        placeholder="<?php echo e($placeholder); ?>"
        <?php echo e($attributes->merge(['class' => 'mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500'])); ?>

    >
    <input type="hidden" name="<?php echo e($name); ?>" :value="selectedId" <?php if($required): ?> required <?php endif; ?>>

    <ul
        x-show="open"
        style="display: none;"
        class="absolute z-10 mt-1 max-h-56 w-full overflow-auto rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
    >
        <template x-for="[id, label] in Object.entries(filtered)" :key="id">
            <li
                @click="select(id, label)"
                class="cursor-pointer select-none px-3 py-2 hover:bg-indigo-50"
                :class="{ 'bg-indigo-50': selectedId == id }"
                x-text="label"
            ></li>
        </template>
        <li x-show="Object.keys(filtered).length === 0" class="px-3 py-2 text-gray-400 select-none">Aucun résultat</li>
    </ul>
</div>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/components/searchable-select.blade.php ENDPATH**/ ?>