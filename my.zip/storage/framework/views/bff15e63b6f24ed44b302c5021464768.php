<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['chemin', 'auteur' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['chemin', 'auteur' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    use Illuminate\Support\Facades\Storage;

    $url      = asset('storage/' . $chemin);
    $ext      = strtoupper(pathinfo($chemin, PATHINFO_EXTENSION));
    $present  = Storage::disk('public')->exists($chemin);
    $taille   = $present ? Storage::disk('public')->size($chemin) : 0;
?>

<?php if(! $present): ?>
    
    <div class="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
        <p class="font-medium">Enregistrement introuvable sur le serveur.</p>
        <p class="mt-1 text-xs">
            Le rendu est bien référencé, mais le fichier n'est pas accessible.
            Cela vient généralement du lien de stockage : lancez
            <span class="font-mono">storage:link</span> depuis la page de maintenance.
        </p>
        <p class="mt-1 text-xs font-mono break-all opacity-75"><?php echo e($chemin); ?></p>
    </div>
<?php elseif($taille < 1024): ?>
    <div class="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
        <p class="font-medium">Enregistrement vide (<?php echo e($taille); ?> octets).</p>
        <p class="mt-1 text-xs">L'apprenant doit le refaire : rien n'a été capté au moment du dépôt.</p>
    </div>
<?php else: ?>
    <div class="space-y-2">
        
        <audio controls preload="metadata" class="w-full max-w-lg"
               <?php if($auteur): ?> aria-label="Enregistrement de <?php echo e($auteur); ?>" <?php endif; ?>>
            <source src="<?php echo e($url); ?>">
            Votre navigateur ne peut pas lire ce fichier audio.
        </audio>

        <div class="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
            <span class="text-gray-500">Format <?php echo e($ext); ?> &middot; <?php echo e(number_format($taille / 1024, 0, ',', ' ')); ?> Ko</span>
            <a href="<?php echo e($url); ?>" target="_blank" rel="noopener" class="text-indigo-600 hover:underline">Ouvrir dans un nouvel onglet</a>
            <a href="<?php echo e($url); ?>" download class="text-indigo-600 hover:underline">Télécharger</a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/components/rendu-audio.blade.php ENDPATH**/ ?>