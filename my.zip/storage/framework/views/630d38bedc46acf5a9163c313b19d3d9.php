<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Niveau d\'anglais')); ?> &mdash; <?php echo e($student->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded-md text-sm">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <?php if (isset($component)) { $__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frise-niveaux','data' => ['echelle' => $echelle,'niveau' => $student->englishLevel,'anime' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frise-niveaux'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['echelle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($echelle),'niveau' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->englishLevel),'anime' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9)): ?>
<?php $attributes = $__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9; ?>
<?php unset($__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9)): ?>
<?php $component = $__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9; ?>
<?php unset($__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9); ?>
<?php endif; ?>
                </div>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-1">
                        <?php echo e($student->englishLevel ? 'Faire évoluer le niveau' : 'Attribuer le niveau initial'); ?>

                    </h3>
                    <p class="text-sm text-gray-500 mb-5">
                        Le changement est décidé par le formateur ou l'administrateur. Il est enregistré
                        dans l'historique ci-dessous, avec son auteur.
                    </p>

                    <form method="POST" action="<?php echo e(route('students.level.update', $student)); ?>" class="flex flex-wrap items-end gap-4">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="min-w-[16rem]">
                            <label for="english_level_id" class="block text-sm font-medium text-gray-700">Palier</label>
                            <select name="english_level_id" id="english_level_id" required
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                <?php $__currentLoopData = $echelle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($palier->id); ?>" <?php echo e($student->english_level_id == $palier->id ? 'selected' : ''); ?>>
                                        <?php echo e($palier->label); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['english_level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium hover:bg-indigo-700">
                            Enregistrer le niveau
                        </button>
                    </form>
                </div>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-4">Historique de progression</h3>

                    <?php $__empty_1 = true; $__currentLoopData = $historique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border-l-2 border-gray-200 pl-4 pb-4 last:pb-0 relative">
                            <span class="absolute -left-[5px] top-1.5 h-2 w-2 rounded-full bg-indigo-500"></span>
                            <p class="text-sm">
                                <?php if($etape->avant): ?>
                                    <span class="font-medium"><?php echo e($etape->avant); ?></span>
                                    <span class="mx-1 text-gray-400">&rarr;</span>
                                    <span class="font-bold text-indigo-700"><?php echo e($etape->apres); ?></span>
                                <?php else: ?>
                                    Niveau initial : <span class="font-bold text-indigo-700"><?php echo e($etape->apres); ?></span>
                                <?php endif; ?>
                            </p>
                            <p class="text-xs text-gray-500 mt-0.5">
                                <?php echo e($etape->date->format('d/m/Y à H:i')); ?> &middot; par <?php echo e($etape->auteur); ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-500 italic">
                            Aucun changement enregistré pour le moment.
                        </p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/levels/edit.blade.php ENDPATH**/ ?>