<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Rapport de session : <?php echo e($session->courseClass->name); ?> le <?php echo e(\Carbon\Carbon::parse($session->start_time)->format('d/m/Y')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <?php if($errors->any()): ?>
                        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>- <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('coach.sessions.report.store', $session)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            
                            <!-- Rapport Pédagogique -->
                            <div class="space-y-4">
                                <h3 class="font-bold text-lg border-b pb-2">Rapport Pédagogique</h3>
                                
                                <div>
                                    <label for="progress_summary" class="block text-sm font-medium text-gray-700">Résumé de la progression *</label>
                                    <textarea name="progress_summary" id="progress_summary" rows="4" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Thèmes abordés, objectifs atteints..."><?php echo e(old('progress_summary')); ?></textarea>
                                </div>
                                
                                <div>
                                    <label for="observations" class="block text-sm font-medium text-gray-700">Observations (Optionnel)</label>
                                    <textarea name="observations" id="observations" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="Remarques générales, difficultés rencontrées, etc."><?php echo e(old('observations')); ?></textarea>
                                </div>
                            </div>

                            <!-- Présences -->
                            <div>
                                <h3 class="font-bold text-lg border-b pb-2 mb-4">Présences</h3>
                                <p class="text-sm text-gray-500 mb-4">Cochez les étudiants qui étaient présents à cette session.</p>
                                
                                <div class="bg-gray-50 p-4 rounded-md">
                                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="mb-3 flex items-center">
                                            <input type="checkbox" name="attendances[<?php echo e($student->id); ?>]" id="student_<?php echo e($student->id); ?>" value="1" 
                                                class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500 h-5 w-5"
                                                <?php echo e(old('attendances.'.$student->id) ? 'checked' : ''); ?>>
                                            <label for="student_<?php echo e($student->id); ?>" class="ml-3 text-sm font-medium text-gray-700">
                                                <?php echo e($student->name); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p class="text-sm text-yellow-600">Aucun étudiant assigné à cette classe.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="mt-8 flex items-center gap-4 border-t pt-4">
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Valider le rapport et les présences
                            </button>
                            <a href="<?php echo e(route('coach.dashboard')); ?>" class="text-sm text-gray-600 hover:underline">Annuler</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/coach/sessions/report.blade.php ENDPATH**/ ?>