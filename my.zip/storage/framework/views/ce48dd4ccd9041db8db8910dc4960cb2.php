<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Mon emploi du temps')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-4">
                        À venir <span class="text-gray-400 normal-case">(<?php echo e($aVenir->count()); ?>)</span>
                    </h3>

                    <?php $__empty_1 = true; $__currentLoopData = $aVenir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $aujourdhui = $s->start_time->isToday(); ?>
                        <div class="flex flex-wrap items-center gap-4 rounded-lg border <?php echo e($aujourdhui ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200'); ?> p-4 mb-3 last:mb-0">
                            <div class="text-center shrink-0 w-16">
                                <p class="text-2xl font-bold <?php echo e($aujourdhui ? 'text-indigo-700' : 'text-gray-900'); ?>"><?php echo e($s->start_time->format('d')); ?></p>
                                <p class="text-xs uppercase text-gray-500"><?php echo e($s->start_time->translatedFormat('M')); ?></p>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-gray-900"><?php echo e($s->courseClass->name ?? '—'); ?></p>
                                <p class="text-sm text-gray-700">
                                    <?php echo e($s->start_time->translatedFormat('l')); ?>

                                    de <?php echo e($s->start_time->format('H:i')); ?> à <?php echo e($s->end_time->format('H:i')); ?>

                                    <?php if($aujourdhui): ?>
                                        <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">Aujourd'hui</span>
                                    <?php endif; ?>
                                </p>
                                <p class="text-sm text-gray-500">Formateur : <?php echo e($s->coach->name ?? '—'); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-500 italic">Aucun cours programmé pour le moment.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-4">
                        Séances passées <span class="text-gray-400 normal-case">(<?php echo e($passees->total()); ?>)</span>
                    </h3>

                    <?php if($passees->count()): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse text-sm">
                                <thead>
                                    <tr>
                                        <th class="border-b py-2 px-3">Date</th>
                                        <th class="border-b py-2 px-3">Horaires</th>
                                        <th class="border-b py-2 px-3">Classe</th>
                                        <th class="border-b py-2 px-3">Formateur</th>
                                        <th class="border-b py-2 px-3 text-center">État</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $passees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="border-b py-2 px-3"><?php echo e($s->start_time->format('d/m/Y')); ?></td>
                                            <td class="border-b py-2 px-3 text-gray-600"><?php echo e($s->start_time->format('H:i')); ?> – <?php echo e($s->end_time->format('H:i')); ?></td>
                                            <td class="border-b py-2 px-3"><?php echo e($s->courseClass->name ?? '—'); ?></td>
                                            <td class="border-b py-2 px-3 text-gray-600"><?php echo e($s->coach->name ?? '—'); ?></td>
                                            <td class="border-b py-2 px-3 text-center">
                                                <?php if($s->status === 'cancelled'): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Annulée</span>
                                                <?php elseif(in_array($s->status, ['completed', 'validated'])): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Effectuée</span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">Prévue</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4"><?php echo e($passees->links()); ?></div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucune séance passée.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\public_html\my\app\resources\views/student/espace/emploi-du-temps.blade.php ENDPATH**/ ?>