<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['titre', 'valeur', 'unite' => null, 'detail' => null, 'couleur' => 'indigo', 'lien' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['titre', 'valeur', 'unite' => null, 'detail' => null, 'couleur' => 'indigo', 'lien' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // Le liseré de bas distingue les rubriques au premier coup d'œil, sans
    // colorer toute la carte — ce qui rendrait la grille illisible.
    $liseres = [
        'indigo' => 'bg-indigo-500', 'green'  => 'bg-green-500',
        'amber'  => 'bg-amber-500',  'red'    => 'bg-red-500',
        'blue'   => 'bg-blue-500',   'purple' => 'bg-purple-500',
        'gray'   => 'bg-gray-400',
    ];
    $textes = [
        'indigo' => 'text-indigo-700', 'green'  => 'text-green-700',
        'amber'  => 'text-amber-700',  'red'    => 'text-red-700',
        'blue'   => 'text-blue-700',   'purple' => 'text-purple-700',
        'gray'   => 'text-gray-700',
    ];

    $balise = $lien ? 'a' : 'div';
?>

<<?php echo e($balise); ?> <?php if($lien): ?> href="<?php echo e($lien); ?>" <?php endif; ?>
    class="block bg-white overflow-hidden shadow-sm sm:rounded-lg <?php echo e($lien ? 'transition hover:shadow-md focus:outline-none focus:ring-2 focus:ring-indigo-400' : ''); ?>">
    <div class="p-5">
        <p class="text-gray-500 text-xs font-semibold uppercase tracking-wide"><?php echo e($titre); ?></p>
        <p class="mt-2 text-3xl font-bold <?php echo e($textes[$couleur] ?? $textes['indigo']); ?>">
            <?php echo e($valeur); ?><?php if($unite): ?><span class="ml-1 text-sm font-medium text-gray-500"><?php echo e($unite); ?></span><?php endif; ?>
        </p>
        <?php if($detail): ?>
            <p class="mt-1 text-xs text-gray-500"><?php echo e($detail); ?></p>
        <?php endif; ?>
    </div>
    <div class="h-1 <?php echo e($liseres[$couleur] ?? $liseres['indigo']); ?>"></div>
</<?php echo e($balise); ?>>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/components/kpi-carte.blade.php ENDPATH**/ ?>