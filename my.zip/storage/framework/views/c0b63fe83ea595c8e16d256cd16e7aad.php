<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Mes prochains cours')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <p class="text-sm text-gray-600 mb-5">
                        <span class="font-semibold text-gray-900"><?php echo e($seances->total()); ?></span>
                        séance<?php echo e($seances->total() > 1 ? 's' : ''); ?> à venir.
                    </p>

                    <?php if($seances->count()): ?>
                        <div class="space-y-3">
                            <?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $aujourdhui = $s->start_time->isToday(); ?>
                                <div class="flex flex-wrap items-center gap-4 rounded-lg border <?php echo e($aujourdhui ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200'); ?> p-4">
                                    <div class="text-center shrink-0 w-16">
                                        <p class="text-2xl font-bold <?php echo e($aujourdhui ? 'text-indigo-700' : 'text-gray-900'); ?>"><?php echo e($s->start_time->format('d')); ?></p>
                                        <p class="text-xs uppercase text-gray-500"><?php echo e($s->start_time->translatedFormat('M')); ?></p>
                                    </div>
                                    <div class="min-w-0 flex-1">
                                        <p class="font-semibold text-gray-900"><?php echo e($s->courseClass->name ?? '—'); ?></p>
                                        <p class="text-sm text-gray-500"><?php echo e($s->courseClass->level->program->name ?? ''); ?></p>
                                        <p class="text-sm text-gray-700 mt-0.5">
                                            <?php echo e($s->start_time->translatedFormat('l')); ?>

                                            de <?php echo e($s->start_time->format('H:i')); ?> à <?php echo e($s->end_time->format('H:i')); ?>

                                            <?php if($aujourdhui): ?>
                                                <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">Aujourd'hui</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <a href="<?php echo e(route('coach.sessions.show', $s)); ?>" class="text-sm text-indigo-600 hover:underline shrink-0">Détails</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mt-5"><?php echo e($seances->links()); ?></div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucun cours programmé pour le moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/coach/espace/prochains-cours.blade.php ENDPATH**/ ?>