<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Mes Devoirs')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse whitespace-nowrap">
                        <thead>
                            <tr>
                                <th class="border-b py-2 px-4">Titre du devoir</th>
                                <th class="border-b py-2 px-4">Classe</th>
                                <th class="border-b py-2 px-4">Date limite</th>
                                <th class="border-b py-2 px-4">Statut</th>
                                <th class="border-b py-2 px-4 text-center">Note</th>
                                <th class="border-b py-2 px-4"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $submission = $assignment->submissions->first();
                                    $isLate = \Carbon\Carbon::parse($assignment->due_date)->isPast();
                                ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="border-b py-3 px-4 font-medium"><?php echo e($assignment->title); ?></td>
                                    <td class="border-b py-3 px-4 text-sm text-gray-600"><?php echo e($assignment->courseClass->name ?? 'N/A'); ?></td>
                                    <td class="border-b py-3 px-4 text-sm <?php echo e($isLate && !$submission ? 'text-red-600 font-semibold' : ''); ?>">
                                        <?php echo e(\Carbon\Carbon::parse($assignment->due_date)->format('d/m/Y')); ?>

                                    </td>
                                    <td class="border-b py-3 px-4">
                                        <?php if($submission): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                Rendu le <?php echo e(\Carbon\Carbon::parse($submission->created_at)->format('d/m/Y')); ?>

                                            </span>
                                        <?php elseif($isLate): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                En retard
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                À faire
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b py-3 px-4 text-center font-bold">
                                        <?php if($submission && $submission->grade): ?>
                                            <span class="<?php echo e($submission->grade->score >= 10 ? 'text-green-600' : 'text-red-600'); ?>">
                                                <?php echo e($submission->grade->score); ?>/20
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b py-3 px-4 text-right">
                                        <a href="<?php echo e(route('student.assignments.show', $assignment)); ?>" class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">Consulter</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="py-6 text-center text-gray-500">Vous n'avez aucun devoir pour le moment.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/student/assignments/index.blade.php ENDPATH**/ ?>