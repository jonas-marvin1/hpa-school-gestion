<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Plan de paiement')); ?> &mdash; <?php echo e($student->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded-md text-sm">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="bg-red-50 border border-red-300 text-red-800 px-4 py-3 rounded-md text-sm">
                    <ul class="list-disc list-inside space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($erreur); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <?php if($plan): ?>
                <div class="bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-5">Situation</h3>

                        <div class="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                            <div>
                                <p class="text-xs text-gray-500">Coût total</p>
                                <p class="text-xl font-bold"><?php echo e(number_format($plan->total_amount, 0, ',', ' ')); ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">Déjà réglé</p>
                                <p class="text-xl font-bold text-green-600"><?php echo e(number_format($plan->montantRegle(), 0, ',', ' ')); ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">Reste à payer</p>
                                <p class="text-xl font-bold <?php echo e($plan->soldeRestant() > 0 ? 'text-amber-600' : 'text-green-600'); ?>">
                                    <?php echo e(number_format($plan->soldeRestant(), 0, ',', ' ')); ?>

                                </p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500">Prochaine échéance</p>
                                <?php if($prochaine = $plan->prochaineEcheance()): ?>
                                    <p class="text-xl font-bold <?php echo e($prochaine->due_date->lt(now()->startOfDay()) ? 'text-red-600' : 'text-gray-800'); ?>">
                                        <?php echo e($prochaine->due_date->format('d/m/Y')); ?>

                                    </p>
                                    <p class="text-xs text-gray-500"><?php echo e(number_format($prochaine->amount, 0, ',', ' ')); ?> <?php echo e($plan->currency); ?></p>
                                <?php else: ?>
                                    <p class="text-xl font-bold text-green-600">Soldé</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="w-full bg-gray-200 rounded-full h-3">
                            <div class="bg-green-600 h-3 rounded-full transition-all duration-700" style="width: <?php echo e($plan->progression()); ?>%"></div>
                        </div>
                        <p class="text-right text-xs text-gray-500 mt-2"><?php echo e($plan->progression()); ?>% de la formation réglée</p>

                        <?php if($plan->echeances->count()): ?>
                            <div class="mt-6 overflow-x-auto">
                                <table class="w-full text-left border-collapse text-sm">
                                    <thead>
                                        <tr>
                                            <th class="border-b py-2 px-3">Échéance</th>
                                            <th class="border-b py-2 px-3 text-right">Montant</th>
                                            <th class="border-b py-2 px-3 text-center">État</th>
                                            <th class="border-b py-2 px-3 text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $plan->echeances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="border-b py-2 px-3"><?php echo e($e->due_date->format('d/m/Y')); ?></td>
                                                <td class="border-b py-2 px-3 text-right font-medium"><?php echo e(number_format($e->amount, 0, ',', ' ')); ?></td>
                                                <td class="border-b py-2 px-3 text-center">
                                                    <?php if($e->status === 'paid'): ?>
                                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Réglée</span>
                                                    <?php elseif($e->due_date->lt(now()->startOfDay())): ?>
                                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">En retard</span>
                                                    <?php else: ?>
                                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">À venir</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="border-b py-2 px-3 text-center">
                                                    <?php if($e->status !== 'paid'): ?>
                                                        <form method="POST" action="<?php echo e(route('admin.echeances.payee', $e)); ?>" class="inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>
                                                            <button type="submit" class="text-indigo-600 hover:underline">Marquer réglée</button>
                                                        </form>
                                                    <?php else: ?>
                                                        <span class="text-xs text-gray-400"><?php echo e($e->paid_date?->format('d/m/Y')); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6"
                     x-data="planPaiement({
                        total: <?php echo e(old('total_amount', $plan->total_amount ?? 0)); ?>,
                        avance: <?php echo e(old('advance_amount', $plan->advance_amount ?? 0)); ?>,
                        dejaRegle: <?php echo e($plan ? (float) $plan->echeances->where('status', 'paid')->sum('amount') : 0); ?>,
                        lignes: <?php echo e(json_encode(old('echeances', $plan
                            ? $plan->echeances->where('status', '!=', 'paid')->map(fn($e) => ['amount' => (float) $e->amount, 'due_date' => $e->due_date->format('Y-m-d')])->values()
                            : [['amount' => '', 'due_date' => '']]))); ?>

                     })">

                    <h3 class="text-lg font-semibold mb-1"><?php echo e($plan ? 'Modifier le plan' : 'Créer le plan de paiement'); ?></h3>
                    <p class="text-sm text-gray-500 mb-6">
                        Renseignez le coût total, l'avance versée à l'inscription, puis répartissez
                        le solde en échéances. Les rappels partiront automatiquement avant chacune.
                        <?php if($plan && $plan->echeances->where('status', 'paid')->count()): ?>
                            <br><span class="text-amber-700">Les échéances déjà réglées sont conservées et ne figurent pas ci-dessous.</span>
                        <?php endif; ?>
                    </p>

                    <form method="POST" action="<?php echo e(route('admin.students.plan.store', $student)); ?>">
                        <?php echo csrf_field(); ?>

                        
                        <div class="mb-5 text-sm">
                            <span class="text-gray-500">Programme suivi :</span>
                            <?php if($programme): ?>
                                <span class="font-medium text-gray-900"><?php echo e($programme->name); ?></span>
                                <span class="text-gray-400">— déduit de la classe de l'apprenant</span>
                            <?php else: ?>
                                <span class="text-amber-700">aucun — cet apprenant n'est affecté à aucune classe</span>
                            <?php endif; ?>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label for="total_amount" class="block text-sm font-medium text-gray-700">Coût total de la formation *</label>
                                <input type="number" step="1" min="0" name="total_amount" id="total_amount" required
                                       x-model.number="total"
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="advance_amount" class="block text-sm font-medium text-gray-700">Avance versée *</label>
                                <input type="number" step="1" min="0" name="advance_amount" id="advance_amount" required
                                       x-model.number="avance"
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>

                        <div class="flex items-center justify-between mb-3">
                            <h4 class="text-sm font-semibold text-gray-700">Échéances</h4>
                            <button type="button" @click="ajouter()" class="text-sm text-indigo-600 hover:underline">+ Ajouter une échéance</button>
                        </div>

                        <div class="space-y-3 mb-4">
                            <template x-for="(ligne, i) in lignes" :key="i">
                                <div class="flex flex-wrap items-end gap-3">
                                    <div class="flex-1 min-w-[10rem]">
                                        <label class="block text-xs text-gray-500" :for="'ech-date-' + i">Date d'échéance</label>
                                        <input type="date" :name="'echeances[' + i + '][due_date]'" :id="'ech-date-' + i" x-model="ligne.due_date" required
                                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                    </div>
                                    <div class="flex-1 min-w-[10rem]">
                                        <label class="block text-xs text-gray-500" :for="'ech-montant-' + i">Montant</label>
                                        <input type="number" step="1" min="1" :name="'echeances[' + i + '][amount]'" :id="'ech-montant-' + i" x-model.number="ligne.amount" required
                                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                    </div>
                                    <button type="button" @click="retirer(i)" x-show="lignes.length > 1"
                                            class="px-3 py-2 text-sm text-red-600 hover:underline">Retirer</button>
                                </div>
                            </template>
                        </div>

                        
                        <div class="rounded-md border p-4 mb-6 text-sm"
                             :class="equilibre ? 'bg-green-50 border-green-300 text-green-800' : 'bg-amber-50 border-amber-300 text-amber-800'">
                            <div class="flex flex-wrap justify-between gap-2">
                                <span>Reste à répartir : <strong x-text="format(resteARepartir)"></strong></span>
                                <span>Total des échéances saisies : <strong x-text="format(sommeEcheances)"></strong></span>
                            </div>
                            <p class="mt-2" x-show="!equilibre" x-cloak>
                                Écart de <strong x-text="format(Math.abs(resteARepartir - sommeEcheances))"></strong> :
                                le plan doit se boucler pour être enregistré.
                            </p>
                            <p class="mt-2" x-show="equilibre" x-cloak>Le plan est équilibré.</p>
                        </div>

                        <div class="mb-6">
                            <label for="notes" class="block text-sm font-medium text-gray-700">Note interne</label>
                            <textarea name="notes" id="notes" rows="2" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"><?php echo e(old('notes', $plan->notes ?? '')); ?></textarea>
                        </div>

                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium hover:bg-indigo-700">
                            <?php echo e($plan ? 'Enregistrer les modifications' : 'Créer le plan'); ?>

                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <script>
        function planPaiement(donnees) {
            return {
                total: donnees.total,
                avance: donnees.avance,
                dejaRegle: donnees.dejaRegle || 0,
                lignes: donnees.lignes.length ? donnees.lignes : [{ amount: '', due_date: '' }],

                get sommeEcheances() {
                    return this.lignes.reduce((s, l) => s + (parseFloat(l.amount) || 0), 0);
                },
                // Les echeances deja reglees sont conservees et ne figurent pas
                // dans le formulaire : elles sont donc deduites du reste a repartir.
                get resteARepartir() {
                    return this.total - this.avance - this.dejaRegle;
                },
                get equilibre() {
                    return Math.abs(this.resteARepartir - this.sommeEcheances) < 1;
                },
                ajouter() {
                    this.lignes.push({ amount: '', due_date: '' });
                },
                retirer(i) {
                    this.lignes.splice(i, 1);
                },
                format(n) {
                    return new Intl.NumberFormat('fr-FR').format(Math.round(n || 0));
                },
            };
        }
    </script>
    <style>[x-cloak] { display: none !important; }</style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/admin/payment_plans/edit.blade.php ENDPATH**/ ?>