<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['echelle', 'niveau' => null, 'anime' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['echelle', 'niveau' => null, 'anime' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $atteint = $niveau?->position ?? 0;
    $total   = $echelle->max('position') ?: 1;
    $avance  = (int) round($atteint / $total * 100);
?>

<div class="w-full">
    <div class="flex items-baseline justify-between mb-3">
        <span class="text-sm font-medium text-gray-700">
            <?php if($niveau): ?>
                Niveau actuel : <span class="font-bold text-indigo-600"><?php echo e($niveau->code); ?></span>
            <?php else: ?>
                Niveau non encore attribué
            <?php endif; ?>
        </span>
        <span class="text-sm font-bold text-indigo-600"><?php echo e($avance); ?>%</span>
    </div>

    
    <div class="relative">
        <div class="absolute top-3 left-0 right-0 h-1.5 bg-gray-200 rounded-full"></div>
        <div class="absolute top-3 left-0 h-1.5 bg-indigo-600 rounded-full <?php echo e($anime ? 'transition-all duration-1000 ease-out' : ''); ?>"
             style="width: <?php echo e($avance); ?>%"></div>

        <ol class="relative flex justify-between">
            <?php $__currentLoopData = $echelle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $franchi = $palier->position <= $atteint;
                    $courant = $niveau && $palier->position === $atteint;
                ?>
                <li class="flex flex-col items-center" style="flex: 1 1 0">
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'flex h-7 w-7 items-center justify-center rounded-full border-2 text-[10px] font-bold',
                        'bg-indigo-600 border-indigo-600 text-white'      => $franchi && ! $courant,
                        'bg-white border-indigo-600 text-indigo-700 ring-4 ring-indigo-100' => $courant,
                        'bg-white border-gray-300 text-gray-400'          => ! $franchi,
                    ]); ?>"
                    <?php if($courant): ?> aria-current="step" <?php endif; ?>
                    title="<?php echo e($palier->label); ?>">
                        <?php if($franchi && ! $courant): ?>
                            &check;
                        <?php else: ?>
                            <?php echo e($loop->iteration); ?>

                        <?php endif; ?>
                    </span>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'mt-2 text-[11px] font-semibold',
                        'text-indigo-700' => $courant,
                        'text-gray-700'   => $franchi && ! $courant,
                        'text-gray-400'   => ! $franchi,
                    ]); ?>"><?php echo e($palier->code); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>

    <?php if($niveau): ?>
        <p class="mt-4 text-xs text-gray-500">
            <?php echo e($niveau->label); ?>

            <?php if($suivant = $niveau->suivant()): ?>
                &middot; prochain palier : <span class="font-medium text-gray-700"><?php echo e($suivant->code); ?></span>
            <?php else: ?>
                &middot; <span class="font-medium text-gray-700">dernier palier de l'échelle</span>
            <?php endif; ?>
        </p>
    <?php else: ?>
        <p class="mt-4 text-xs text-gray-500">
            Votre niveau sera positionné par votre formateur.
        </p>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\public_html\my\app\resources\views/components/frise-niveaux.blade.php ENDPATH**/ ?>