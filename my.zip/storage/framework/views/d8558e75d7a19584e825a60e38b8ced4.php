<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Affectations pour : <?php echo e($courseClass->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="<?php echo e(route('manager.classes.assign.update', ['courseClass' => $courseClass->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-6">
                            <input type="text" id="user-search" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="Rechercher un formateur ou un apprenant (Nom, Email)...">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <!-- Formateurs -->
                            <div>
                                <h3 class="font-bold text-lg mb-4 border-b pb-2">Formateurs (Coaches)</h3>
                                <?php $__empty_1 = true; $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="mb-2 flex items-center user-item">
                                        <input type="radio" name="coach_id" id="user_<?php echo e($coach->id); ?>" value="<?php echo e($coach->id); ?>" 
                                            class="rounded-full border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500"
                                            <?php echo e(in_array($coach->id, $assignedUserIds) ? 'checked' : ''); ?> required>
                                        <label for="user_<?php echo e($coach->id); ?>" class="ml-2 text-sm text-gray-700 user-label"><?php echo e($coach->name); ?> (<?php echo e($coach->email); ?>)</label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-sm text-gray-500">Aucun formateur enregistré.</p>
                                <?php endif; ?>
                            </div>

                            <!-- Apprenants -->
                            <div>
                                <h3 class="font-bold text-lg mb-4 border-b pb-2">Apprenants (Students)</h3>
                                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="mb-2 flex items-center user-item">
                                        <input type="checkbox" name="student_ids[]" id="user_<?php echo e($student->id); ?>" value="<?php echo e($student->id); ?>" 
                                            class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500"
                                            <?php echo e(in_array($student->id, $assignedUserIds) ? 'checked' : ''); ?>>
                                        <label for="user_<?php echo e($student->id); ?>" class="ml-2 text-sm text-gray-700 user-label"><?php echo e($student->name); ?> (<?php echo e($student->email); ?>)</label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-sm text-gray-500">Aucun apprenant enregistré.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mt-8 flex items-center gap-4">
                            <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Enregistrer les affectations
                            </button>
                            <a href="<?php echo e(route('manager.classes.index')); ?>" class="text-sm text-gray-600 hover:underline">Annuler</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('user-search');
            const userItems = document.querySelectorAll('.user-item');

            searchInput.addEventListener('input', function(e) {
                const term = e.target.value.toLowerCase();
                
                userItems.forEach(function(item) {
                    const label = item.querySelector('.user-label').textContent.toLowerCase();
                    if (label.includes(term)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/manager/classes/assign.blade.php ENDPATH**/ ?>