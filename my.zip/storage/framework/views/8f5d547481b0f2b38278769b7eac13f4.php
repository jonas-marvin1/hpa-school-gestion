<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Espace Gestionnaire')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Statistiques Rapides -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="bg-indigo-600 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-white">
                        <h3 class="font-bold text-sm mb-1 opacity-80">Classes Actives</h3>
                        <p class="text-3xl"><?php echo e($totalClasses); ?></p>
                    </div>
                </div>
                <div class="bg-blue-600 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-white">
                        <h3 class="font-bold text-sm mb-1 opacity-80">Sessions (Terminées / Total)</h3>
                        <p class="text-3xl"><?php echo e($kpis['completed_sessions']); ?> <span class="text-xl opacity-70">/ <?php echo e($kpis['total_sessions']); ?></span></p>
                    </div>
                </div>
                <div class="bg-red-500 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-white">
                        <h3 class="font-bold text-sm mb-1 opacity-80">Paies en attente (FCFA)</h3>
                        <p class="text-2xl font-bold"><?php echo e(number_format($kpis['pending_payments'], 0, ',', ' ')); ?></p>
                    </div>
                </div>
                <div class="bg-teal-500 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-white">
                        <h3 class="font-bold text-sm mb-1 opacity-80">Paies réglées (FCFA)</h3>
                        <p class="text-2xl font-bold"><?php echo e(number_format($kpis['paid_payments'], 0, ',', ' ')); ?></p>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <!-- Gestion des Classes et Affectations -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 flex flex-col h-full">
                        <h3 class="font-bold text-lg mb-2">Classes & Affectations</h3>
                        <p class="text-sm text-gray-600 mb-4 flex-grow">Inscrire et affecter les apprenants et formateurs aux classes.</p>
                        <a href="<?php echo e(route('manager.classes.index')); ?>" class="text-indigo-600 hover:underline">Gérer les affectations &rarr;</a>
                    </div>
                </div>

                <!-- Planification (Emplois du temps) -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 flex flex-col h-full">
                        <h3 class="font-bold text-lg mb-2">Emplois du temps (Sessions)</h3>
                        <p class="text-sm text-gray-600 mb-4 flex-grow">Créer et gérer les sessions de cours pour les classes.</p>
                        <a href="<?php echo e(route('manager.sessions.index')); ?>" class="text-indigo-600 hover:underline">Voir le planning &rarr;</a>
                    </div>
                </div>

            </div>
            
            <!-- Prochaines sessions (Vue Rapide) -->
            <div class="mt-6 bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="font-bold text-lg mb-4 border-b pb-2">Prochaines Sessions (Les 5 prochaines)</h3>
                    <?php if($upcomingSessions->count() > 0): ?>
                        <ul class="space-y-3">
                            <?php $__currentLoopData = $upcomingSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex justify-between items-center bg-gray-50 p-3 rounded">
                                    <div>
                                        <span class="font-semibold"><?php echo e(\Carbon\Carbon::parse($session->start_time)->format('d/m/Y')); ?></span> à <?php echo e(\Carbon\Carbon::parse($session->start_time)->format('H:i')); ?>

                                        <span class="mx-2 text-gray-400">|</span>
                                        Classe : <strong><?php echo e(optional($session->courseClass)->name ?? 'N/A'); ?></strong>
                                    </div>
                                    <span class="text-sm text-gray-600"><?php echo e(optional($session->coach)->name ?? 'Formateur non assigné'); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-gray-500">Aucune session à venir.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/manager/dashboard.blade.php ENDPATH**/ ?>