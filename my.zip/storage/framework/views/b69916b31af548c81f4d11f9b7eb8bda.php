<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Mon Espace Apprenant')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <?php if (isset($component)) { $__componentOriginal28c6d5c2102de907f7f10e402c709997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28c6d5c2102de907f7f10e402c709997 = $attributes; } ?>
<?php $component = App\View\Components\AlertesEcheances::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alertes-echeances'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AlertesEcheances::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28c6d5c2102de907f7f10e402c709997)): ?>
<?php $attributes = $__attributesOriginal28c6d5c2102de907f7f10e402c709997; ?>
<?php unset($__attributesOriginal28c6d5c2102de907f7f10e402c709997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28c6d5c2102de907f7f10e402c709997)): ?>
<?php $component = $__componentOriginal28c6d5c2102de907f7f10e402c709997; ?>
<?php unset($__componentOriginal28c6d5c2102de907f7f10e402c709997); ?>
<?php endif; ?>

            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Mon niveau d\'anglais','valeur' => $kpis['niveau'] ?? '—','couleur' => 'purple','lien' => route('student.progression.index'),'detail' => $niveauActuel?->label ?? 'Niveau non encore évalué']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Mon niveau d\'anglais','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['niveau'] ?? '—'),'couleur' => 'purple','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.progression.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($niveauActuel?->label ?? 'Niveau non encore évalué')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Avancement du cursus','valeur' => $kpis['progression_cursus'],'unite' => '%','couleur' => 'indigo','lien' => route('student.progression.index'),'detail' => $sessionsDone . ' séance' . ($sessionsDone > 1 ? 's' : '') . ' sur ' . $sessionsTotal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Avancement du cursus','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['progression_cursus']),'unite' => '%','couleur' => 'indigo','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.progression.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sessionsDone . ' séance' . ($sessionsDone > 1 ? 's' : '') . ' sur ' . $sessionsTotal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Devoirs à rendre','valeur' => $kpis['devoirs_a_rendre'],'couleur' => $kpis['devoirs_a_rendre'] > 0 ? 'amber' : 'green','lien' => route('student.assignments.index'),'detail' => $kpis['devoirs_rendus'] . ' déjà rendu' . ($kpis['devoirs_rendus'] > 1 ? 's' : '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Devoirs à rendre','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['devoirs_a_rendre']),'couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['devoirs_a_rendre'] > 0 ? 'amber' : 'green'),'lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.assignments.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['devoirs_rendus'] . ' déjà rendu' . ($kpis['devoirs_rendus'] > 1 ? 's' : ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Moyenne générale','valeur' => $kpis['moyenne'] !== null ? $kpis['moyenne'] : '—','unite' => $kpis['moyenne'] !== null ? '/20' : null,'couleur' => $kpis['moyenne'] === null ? 'gray' : ($kpis['moyenne'] >= 10 ? 'green' : 'amber'),'lien' => route('student.progression.index'),'detail' => $kpis['moyenne'] !== null ? 'Sur les devoirs notés' : 'Aucun devoir noté']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Moyenne générale','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['moyenne'] !== null ? $kpis['moyenne'] : '—'),'unite' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['moyenne'] !== null ? '/20' : null),'couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['moyenne'] === null ? 'gray' : ($kpis['moyenne'] >= 10 ? 'green' : 'amber')),'lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.progression.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['moyenne'] !== null ? 'Sur les devoirs notés' : 'Aucun devoir noté')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Taux de présence','valeur' => $kpis['assiduite'],'unite' => '%','couleur' => $kpis['assiduite'] >= 80 ? 'green' : 'red','detail' => 'Sur ' . $totalSessions . ' cours']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Taux de présence','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['assiduite']),'unite' => '%','couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['assiduite'] >= 80 ? 'green' : 'red'),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Sur ' . $totalSessions . ' cours')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Prochains cours','valeur' => $kpis['prochains_cours'],'couleur' => 'blue','lien' => route('student.emploi.index'),'detail' => 'Séances à venir']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Prochains cours','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['prochains_cours']),'couleur' => 'blue','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.emploi.index')),'detail' => 'Séances à venir']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Mes programmes','valeur' => $kpis['programmes'],'couleur' => 'purple','lien' => route('student.programme.index'),'detail' => 'Programmes suivis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Mes programmes','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['programmes']),'couleur' => 'purple','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.programme.index')),'detail' => 'Programmes suivis']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php
                    // Le « prochain » paiement est le plus ancien impaye : il peut donc
                    // deja etre echu. L'annoncer comme a venir induirait en erreur.
                    $paiementEnRetard = isset($nextPayment) && $nextPayment->due_date->lt(now()->startOfDay());
                ?>
                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => $paiementEnRetard ? 'Paiement en retard' : 'Prochain paiement','valeur' => $nextPayment ? number_format($nextPayment->amount, 0, ',', ' ') : 'À jour','unite' => $nextPayment ? 'FCFA' : null,'couleur' => $nextPayment ? ($paiementEnRetard ? 'red' : 'amber') : 'green','lien' => route('student.payments.index'),'detail' => $nextPayment
                                 ? ($paiementEnRetard ? 'Échu depuis le ' : 'Échéance du ') . $nextPayment->due_date->format('d/m/Y')
                                 : 'Aucun montant dû']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paiementEnRetard ? 'Paiement en retard' : 'Prochain paiement'),'valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextPayment ? number_format($nextPayment->amount, 0, ',', ' ') : 'À jour'),'unite' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextPayment ? 'FCFA' : null),'couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextPayment ? ($paiementEnRetard ? 'red' : 'amber') : 'green'),'lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('student.payments.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextPayment
                                 ? ($paiementEnRetard ? 'Échu depuis le ' : 'Échéance du ') . $nextPayment->due_date->format('d/m/Y')
                                 : 'Aucun montant dû')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
            </div>

            
            <?php if($pendingFeedbacks->count() > 0): ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 shadow-sm sm:rounded-lg">
                    <div class="flex items-start">
                        <svg class="h-5 w-5 text-yellow-400 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                        </svg>
                        <div class="ml-3 w-full">
                            <h3 class="text-sm font-medium text-yellow-800">Avis en attente</h3>
                            <ul class="mt-2 space-y-2 text-sm text-yellow-700">
                                <?php $__currentLoopData = $pendingFeedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="flex flex-wrap items-center justify-between gap-2">
                                        <span><strong><?php echo e($session->courseClass->name); ?></strong> — <?php echo e(\Carbon\Carbon::parse($session->start_time)->format('d/m/Y')); ?></span>
                                        <a href="<?php echo e(route('student.sessions.feedback.create', $session)); ?>" class="inline-flex items-center px-3 py-1 text-xs font-medium rounded-md text-white bg-yellow-600 hover:bg-yellow-700">
                                            Donner mon avis
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <?php if($upcomingSessions->count()): ?>
                <div class="bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-baseline justify-between mb-4">
                            <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide">Mon prochain cours</h3>
                            <a href="<?php echo e(route('student.emploi.index')); ?>" class="text-sm text-indigo-600 hover:underline">Tout voir</a>
                        </div>

                        <?php $s = $upcomingSessions->first(); ?>
                        <div class="flex flex-wrap items-center gap-4 rounded-lg border <?php echo e($s->start_time->isToday() ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200'); ?> p-4">
                            <div class="text-center shrink-0 w-16">
                                <p class="text-2xl font-bold <?php echo e($s->start_time->isToday() ? 'text-indigo-700' : 'text-gray-900'); ?>"><?php echo e($s->start_time->format('d')); ?></p>
                                <p class="text-xs uppercase text-gray-500"><?php echo e($s->start_time->translatedFormat('M')); ?></p>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-gray-900"><?php echo e($s->courseClass->name ?? '—'); ?></p>
                                <p class="text-sm text-gray-700">
                                    <?php echo e($s->start_time->translatedFormat('l')); ?>

                                    de <?php echo e($s->start_time->format('H:i')); ?> à <?php echo e($s->end_time->format('H:i')); ?>

                                    <?php if($s->start_time->isToday()): ?>
                                        <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">Aujourd'hui</span>
                                    <?php endif; ?>
                                </p>
                                <p class="text-sm text-gray-500">
                                    <?php if($s->intervention_type === 'online' && $s->online_link): ?>
                                        <a href="<?php echo e($s->online_link); ?>" target="_blank" rel="noopener" class="text-blue-600 hover:underline font-medium">Rejoindre le cours (en ligne)</a>
                                    <?php elseif($s->intervention_type === 'online'): ?>
                                        En ligne
                                    <?php else: ?>
                                        Présentiel<?php echo e(($s->courseClass->location ?? null) ? ' — ' . $s->courseClass->location : ''); ?>

                                    <?php endif; ?>
                                    &middot; Coach : <?php echo e($s->coach->name ?? '—'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/student/dashboard.blade.php ENDPATH**/ ?>