<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Emplois du temps (Sessions)')); ?>

            </h2>
            <a href="<?php echo e(route('manager.sessions.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 text-sm font-medium">
                Nouvelle Session
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('status')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="GET" action="<?php echo e(route('manager.sessions.index')); ?>" class="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4 bg-gray-50 p-4 rounded-md border">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Recherche</label>
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Classe ou formateur..." class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Formateur</label>
                            <select name="coach_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <option value="">Tous</option>
                                <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($coach->id); ?>" <?php echo e(request('coach_id') == $coach->id ? 'selected' : ''); ?>>
                                        <?php echo e($coach->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Statut</label>
                            <select name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <option value="">Tous</option>
                                <option value="scheduled" <?php echo e(request('status') == 'scheduled' ? 'selected' : ''); ?>>Prévue</option>
                                <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Effectuée</option>
                                <option value="validated" <?php echo e(request('status') == 'validated' ? 'selected' : ''); ?>>Validée</option>
                                <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Annulée</option>
                            </select>
                        </div>
                        <div class="flex items-end gap-2">
                            <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 font-medium text-sm w-full md:w-auto">
                                Filtrer
                            </button>
                            <a href="<?php echo e(route('manager.sessions.index')); ?>" class="bg-gray-200 text-gray-800 px-4 py-2 rounded-md hover:bg-gray-300 font-medium text-sm w-full md:w-auto text-center">
                                Réinitialiser
                            </a>
                        </div>
                    </form>

                    
                    <p class="text-sm text-gray-600 mb-4">
                        <span class="font-semibold text-gray-900"><?php echo e($sessions->total()); ?></span>
                        séance<?php echo e($sessions->total() > 1 ? 's' : ''); ?>

                        <?php if(request()->hasAny(['search', 'status', 'coach_id'])): ?>
                            <span class="text-gray-500">pour ce filtre</span>
                        <?php endif; ?>
                        <?php if($sessions->hasPages()): ?>
                            <span class="text-gray-400">— page <?php echo e($sessions->currentPage()); ?> sur <?php echo e($sessions->lastPage()); ?></span>
                        <?php endif; ?>
                    </p>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse whitespace-nowrap">
                        <thead>
                            <tr>
                                <th class="border-b py-2 px-4">Date</th>
                                <th class="border-b py-2 px-4">Horaires</th>
                                <th class="border-b py-2 px-4">Classe</th>
                                <th class="border-b py-2 px-4">Formateur</th>
                                <th class="border-b py-2 px-4 text-right">Montant</th>
                                <th class="border-b py-2 px-4">Statut</th>
                                <th class="border-b py-2 px-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="border-b py-2 px-4"><?php echo e($session->start_time->format('d/m/Y')); ?></td>
                                    <td class="border-b py-2 px-4">
                                        <?php echo e($session->start_time->format('H:i')); ?> - 
                                        <?php echo e($session->end_time->format('H:i')); ?>

                                    </td>
                                    <td class="border-b py-2 px-4"><?php echo e($session->courseClass->name ?? 'N/A'); ?></td>
                                    <td class="border-b py-2 px-4"><?php echo e($session->coach->name ?? 'N/A'); ?></td>
                                    <td class="border-b py-2 px-4 text-right"><?php echo e(number_format($session->amount, 0, ',', ' ')); ?></td>
                                    <td class="border-b py-2 px-4">
                                        <?php if($session->status === 'scheduled'): ?>
                                            <span class="px-2 py-1 text-xs text-blue-700 bg-blue-100 rounded-full">Prévue</span>
                                        <?php elseif($session->status === 'completed'): ?>
                                            <span class="px-2 py-1 text-xs text-yellow-700 bg-yellow-100 rounded-full" title="En attente de validation">Effectuée</span>
                                        <?php elseif($session->status === 'validated'): ?>
                                            <span class="px-2 py-1 text-xs text-green-700 bg-green-100 rounded-full">Validée</span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 text-xs text-gray-700 bg-gray-100 rounded-full">Annulée</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b py-2 px-4 flex gap-2">
                                        <a href="<?php echo e(route('manager.sessions.show', $session)); ?>" class="text-indigo-600 hover:underline">Détails</a>
                                        <a href="<?php echo e(route('manager.sessions.edit', $session)); ?>" class="text-indigo-600 hover:underline">Modifier</a>
                                        <form action="<?php echo e(route('manager.sessions.destroy', $session)); ?>" method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette session ?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:underline">Supprimer</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="py-4 text-center text-gray-500">Aucune session programmée.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($sessions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/manager/sessions/index.blade.php ENDPATH**/ ?>