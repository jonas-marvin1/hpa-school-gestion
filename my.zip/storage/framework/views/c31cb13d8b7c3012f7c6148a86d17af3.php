<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Mes programmes')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <p class="text-sm text-gray-600 mb-5">
                        <span class="font-semibold text-gray-900"><?php echo e($programmes->count()); ?></span>
                        programme<?php echo e($programmes->count() > 1 ? 's' : ''); ?> sur
                        <?php echo e($programmes->count() > 1 ? 'lesquels' : 'lequel'); ?> vous intervenez.
                    </p>

                    <div class="space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if (isset($component)) { $__componentOriginal0fe59df9c806405119b693da7f03d195 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0fe59df9c806405119b693da7f03d195 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.programme-detail','data' => ['programme' => $entree->programme,'sousTitre' => ($entree->classes->count() > 1 ? 'Classes : ' : 'Classe : ') . $entree->classes->implode(', '),'ouvert' => $programmes->count() === 1]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('programme-detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['programme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entree->programme),'sous-titre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($entree->classes->count() > 1 ? 'Classes : ' : 'Classe : ') . $entree->classes->implode(', ')),'ouvert' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($programmes->count() === 1)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0fe59df9c806405119b693da7f03d195)): ?>
<?php $attributes = $__attributesOriginal0fe59df9c806405119b693da7f03d195; ?>
<?php unset($__attributesOriginal0fe59df9c806405119b693da7f03d195); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0fe59df9c806405119b693da7f03d195)): ?>
<?php $component = $__componentOriginal0fe59df9c806405119b693da7f03d195; ?>
<?php unset($__componentOriginal0fe59df9c806405119b693da7f03d195); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-gray-500 italic">
                                Aucun programme : vous n'avez encore aucune séance rattachée à une classe.
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\public_html\my\app\resources\views/coach/espace/programmes.blade.php ENDPATH**/ ?>