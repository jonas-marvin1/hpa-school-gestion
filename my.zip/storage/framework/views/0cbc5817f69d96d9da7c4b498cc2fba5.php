<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['programme', 'sousTitre' => null, 'ouvert' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['programme', 'sousTitre' => null, 'ouvert' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>


<details class="group rounded-lg border border-gray-200 bg-white" <?php if($ouvert): ?> open <?php endif; ?>>
    <summary class="flex items-start justify-between gap-3 cursor-pointer list-none p-4 hover:bg-gray-50 rounded-lg">
        <div class="min-w-0">
            <p class="font-semibold text-gray-900"><?php echo e($programme->name); ?></p>
            <?php if($sousTitre): ?>
                <p class="text-sm text-gray-500 mt-0.5"><?php echo e($sousTitre); ?></p>
            <?php endif; ?>
        </div>

        <span class="flex items-center gap-1.5 text-sm text-indigo-600 whitespace-nowrap shrink-0">
            <span class="group-open:hidden">Voir le programme</span>
            <span class="hidden group-open:inline">Réduire</span>
            <svg class="h-4 w-4 transition-transform group-open:rotate-180" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd" />
            </svg>
        </span>
    </summary>

    <div class="px-4 pb-4 -mt-1">
        <?php if(filled($programme->description)): ?>
            <div class="rounded-md bg-gray-50 border border-gray-200 p-4 text-sm text-gray-800 leading-relaxed whitespace-pre-wrap break-words max-h-[28rem] overflow-y-auto"><?php echo e($programme->description); ?></div>
        <?php else: ?>
            <p class="text-sm text-gray-500 italic">Aucune description n'a encore été rédigée pour ce programme.</p>
        <?php endif; ?>
    </div>
</details>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/components/programme-detail.blade.php ENDPATH**/ ?>