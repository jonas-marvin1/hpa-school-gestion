<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Toutes les notifications')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('status')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium">Vos notifications</h3>
                        <?php if(Auth::user()->unreadNotifications->count() > 0): ?>
                            <form action="<?php echo e(route('notifications.readAll')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-sm text-indigo-600 hover:text-indigo-800 font-medium">
                                    Tout marquer comme lu
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>

                    <div class="divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="py-4 <?php echo e($notification->read_at ? 'opacity-60' : ''); ?>">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h4 class="text-md font-semibold text-gray-900">
                                            <?php echo e($notification->data['title'] ?? 'Notification'); ?>

                                        </h4>
                                        <p class="text-gray-600 mt-1">
                                            <?php echo e($notification->data['message'] ?? ''); ?>

                                        </p>
                                        <div class="mt-2 text-sm text-gray-400">
                                            <?php echo e($notification->created_at->format('d/m/Y H:i')); ?> 
                                            (<?php echo e($notification->created_at->diffForHumans()); ?>)
                                        </div>
                                    </div>
                                    <div class="flex flex-col items-end gap-2">
                                        <?php if(isset($notification->data['action_url'])): ?>
                                            <a href="<?php echo e($notification->data['action_url']); ?>" class="text-sm bg-gray-100 px-3 py-1 rounded hover:bg-gray-200">Voir détails</a>
                                        <?php endif; ?>
                                        
                                        <?php if(!$notification->read_at): ?>
                                            <a href="<?php echo e(route('notifications.read', $notification->id)); ?>" class="text-sm text-indigo-600 hover:underline">Marquer comme lu</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="py-8 text-center text-gray-500">
                                Vous n'avez aucune notification.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-6">
                        <?php echo e($notifications->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/notifications/index.blade.php ENDPATH**/ ?>