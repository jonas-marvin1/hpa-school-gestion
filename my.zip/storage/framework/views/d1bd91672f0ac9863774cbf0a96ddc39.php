<div <?php echo e($attributes->merge(['class' => 'flex items-center gap-2'])); ?>>
    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="HPA Logo" class="h-full object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
    <div style="display: none;" class="text-2xl font-extrabold tracking-tight">
        <span class="text-hpa-blue">HPA</span> <span class="text-hpa-orange">Academy</span>
    </div>
</div>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/components/application-logo.blade.php ENDPATH**/ ?>