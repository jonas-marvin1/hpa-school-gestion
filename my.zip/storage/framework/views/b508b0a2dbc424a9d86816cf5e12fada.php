<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Tableau de bord Administrateur (KPI)')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Alertes -->
            <?php if(count($alerts) > 0): ?>
                <div class="mb-6 space-y-3">
                    <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    <svg class="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <div class="ml-3">
                                    <p class="text-sm text-yellow-700">
                                        <?php echo e($alert['message']); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <!-- KPI Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-indigo-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Total Apprenants</div>
                        <div class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($kpis['total_students']); ?></div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-green-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Total Formateurs</div>
                        <div class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($kpis['total_coaches']); ?></div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-blue-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Classes Actives</div>
                        <div class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($kpis['total_classes']); ?></div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-purple-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Sessions (Toutes / Terminées)</div>
                        <div class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($kpis['total_sessions']); ?> / <span class="text-green-600"><?php echo e($kpis['completed_sessions']); ?></span></div>
                    </div>
                </div>
                
                <!-- Statistiques Financières -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-red-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Paies en attente (FCFA)</div>
                        <div class="mt-1 text-3xl font-semibold text-red-600"><?php echo e(number_format($kpis['pending_payments'], 0, ',', ' ')); ?></div>
                    </div>
                </div>
                
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-b-4 border-teal-500">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 truncate">Paies réglées (FCFA)</div>
                        <div class="mt-1 text-3xl font-semibold text-teal-600"><?php echo e(number_format($kpis['paid_payments'], 0, ',', ' ')); ?></div>
                    </div>
                </div>

            </div>

            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900">
                    <div class="flex flex-wrap items-baseline justify-between gap-3 mb-5">
                        <h3 class="text-lg font-bold">Paiements à relancer</h3>
                        <span class="text-sm text-gray-500"><?php echo e(now()->translatedFormat('l j F Y')); ?></span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        <div class="rounded-lg border border-amber-300 bg-amber-50 p-4">
                            <p class="text-xs font-semibold uppercase tracking-wide text-amber-800">Échéances du jour</p>
                            <p class="text-2xl font-bold text-amber-900 mt-1"><?php echo e(number_format($totalDuJour, 0, ',', ' ')); ?> <span class="text-sm font-medium">FCFA</span></p>
                            <p class="text-xs text-amber-800 mt-1"><?php echo e($echeancesDuJour->count()); ?> apprenant<?php echo e($echeancesDuJour->count() > 1 ? 's' : ''); ?> concerné<?php echo e($echeancesDuJour->count() > 1 ? 's' : ''); ?></p>
                        </div>
                        <div class="rounded-lg border <?php echo e($echeancesEnRetard->count() ? 'border-red-300 bg-red-50' : 'border-green-300 bg-green-50'); ?> p-4">
                            <p class="text-xs font-semibold uppercase tracking-wide <?php echo e($echeancesEnRetard->count() ? 'text-red-800' : 'text-green-800'); ?>">En retard</p>
                            <p class="text-2xl font-bold <?php echo e($echeancesEnRetard->count() ? 'text-red-900' : 'text-green-900'); ?> mt-1"><?php echo e(number_format($totalEnRetard, 0, ',', ' ')); ?> <span class="text-sm font-medium">FCFA</span></p>
                            <p class="text-xs <?php echo e($echeancesEnRetard->count() ? 'text-red-800' : 'text-green-800'); ?> mt-1"><?php echo e($echeancesEnRetard->count()); ?> échéance<?php echo e($echeancesEnRetard->count() > 1 ? 's' : ''); ?> dépassée<?php echo e($echeancesEnRetard->count() > 1 ? 's' : ''); ?></p>
                        </div>
                    </div>

                    <?php $aRelancer = $echeancesEnRetard->concat($echeancesDuJour); ?>

                    <?php if($aRelancer->count()): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse text-sm">
                                <thead>
                                    <tr>
                                        <th class="border-b py-2 px-3">Apprenant</th>
                                        <th class="border-b py-2 px-3">Échéance</th>
                                        <th class="border-b py-2 px-3 text-right">Montant</th>
                                        <th class="border-b py-2 px-3 text-right">Reste dû</th>
                                        <th class="border-b py-2 px-3 text-center">État</th>
                                        <th class="border-b py-2 px-3 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $aRelancer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $retard = $e->due_date->lt(today()); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="border-b py-2 px-3 font-medium"><?php echo e($e->student->name ?? '—'); ?></td>
                                            <td class="border-b py-2 px-3 <?php echo e($retard ? 'text-red-700 font-medium' : ''); ?>">
                                                <?php echo e($e->due_date->format('d/m/Y')); ?>

                                                <?php if($retard): ?>
                                                    <span class="text-xs">(<?php echo e((int) $e->due_date->diffInDays(today())); ?> j)</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="border-b py-2 px-3 text-right font-medium"><?php echo e(number_format($e->amount, 0, ',', ' ')); ?></td>
                                            <td class="border-b py-2 px-3 text-right text-gray-600">
                                                <?php echo e($e->paymentPlan ? number_format($e->paymentPlan->soldeRestant(), 0, ',', ' ') : '—'); ?>

                                            </td>
                                            <td class="border-b py-2 px-3 text-center">
                                                <?php if($retard): ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">En retard</span>
                                                <?php else: ?>
                                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">Aujourd'hui</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="border-b py-2 px-3 text-center whitespace-nowrap">
                                                <a href="<?php echo e(route('admin.students.plan.edit', $e->student_id)); ?>" class="text-indigo-600 hover:underline">Voir le plan</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucune échéance à relancer aujourd'hui.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-bold mb-4">Actions Rapides</h3>
                    <div class="flex flex-wrap gap-4">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">Gérer les utilisateurs</a>
                        <a href="<?php echo e(route('admin.classes.index')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700">Gérer la structure</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>