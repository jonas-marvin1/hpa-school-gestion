<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Évaluations : <?php echo e($assignment->title); ?> (<?php echo e($assignment->courseClass->name); ?>)
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('status')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <div class="overflow-x-auto">
                        
                        <table class="w-full text-left border-collapse mt-4 align-top">
                        <thead>
                            <tr>
                                <th class="border-b py-2 px-4">Apprenant</th>
                                <th class="border-b py-2 px-4">Statut de soumission</th>
                                <th class="border-b py-2 px-4 min-w-[420px]">Rendu</th>
                                <th class="border-b py-2 px-4 text-center">Note (/20)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $submission = $submissions->get($student->id);
                                    $grade = $submission ? $submission->grade : null;
                                ?>
                                <tr>
                                    <td class="border-b py-4 px-4 font-medium"><?php echo e($student->name); ?></td>
                                    <td class="border-b py-4 px-4">
                                        <?php if($submission): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Soumis le <?php echo e(\Carbon\Carbon::parse($submission->created_at)->format('d/m/Y H:i')); ?></span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">En attente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b py-4 px-4 text-sm align-top">
                                        <?php if($submission): ?>
                                            <?php if($assignment->type === 'text'): ?>
                                                
                                                <div class="whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 text-gray-800 leading-relaxed max-h-96 overflow-y-auto"><?php echo e($submission->content_text); ?></div>
                                            <?php elseif($assignment->type === 'link'): ?>
                                                <a href="<?php echo e($submission->content_text); ?>" target="_blank" rel="noopener" class="text-blue-600 hover:underline break-all"><?php echo e($submission->content_text); ?></a>
                                            <?php elseif(empty($submission->file_path)): ?>
                                                
                                                <?php if(filled($submission->content_text)): ?>
                                                    <div class="whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 text-gray-800 leading-relaxed max-h-96 overflow-y-auto"><?php echo e($submission->content_text); ?></div>
                                                <?php else: ?>
                                                    <span class="text-gray-400 italic">Aucun fichier joint</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php
                                                    $ext = strtolower(pathinfo($submission->file_path, PATHINFO_EXTENSION));
                                                    $url = asset('storage/' . $submission->file_path);
                                                ?>
                                                <div class="space-y-2">
                                                    
                                                    <?php if(in_array($ext, ['mp3', 'm4a', 'mp4', 'wav', 'ogg', 'oga', 'webm', 'weba', 'aac', '3gp', '3gpp', 'opus'])): ?>
                                                        <?php if (isset($component)) { $__componentOriginala0c9cb689f073f4804bbba10f772d477 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0c9cb689f073f4804bbba10f772d477 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rendu-audio','data' => ['chemin' => $submission->file_path,'auteur' => $student->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rendu-audio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chemin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($submission->file_path),'auteur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0c9cb689f073f4804bbba10f772d477)): ?>
<?php $attributes = $__attributesOriginala0c9cb689f073f4804bbba10f772d477; ?>
<?php unset($__attributesOriginala0c9cb689f073f4804bbba10f772d477); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0c9cb689f073f4804bbba10f772d477)): ?>
<?php $component = $__componentOriginala0c9cb689f073f4804bbba10f772d477; ?>
<?php unset($__componentOriginala0c9cb689f073f4804bbba10f772d477); ?>
<?php endif; ?>
                                                    <?php elseif(in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                                                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener">
                                                            <img src="<?php echo e($url); ?>" alt="Rendu de <?php echo e($student->name); ?>" class="max-h-96 rounded border border-gray-200">
                                                        </a>
                                                    <?php elseif($ext === 'pdf'): ?>
                                                        <embed src="<?php echo e($url); ?>" type="application/pdf" class="w-full h-96 rounded border border-gray-200">
                                                        
                                                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener" class="inline-block text-blue-600 hover:underline">
                                                            Ouvrir en plein écran (<?php echo e(strtoupper($ext)); ?>)
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b py-4 px-4 min-w-[250px]">
                                        <?php if($submission): ?>
                                            <form action="<?php echo e(route('coach.evaluations.store', $submission)); ?>" method="POST" class="flex flex-col gap-2">
                                                <?php echo csrf_field(); ?>
                                                <input type="number" name="score" min="0" max="20" step="0.5" value="<?php echo e($grade->score ?? ''); ?>" placeholder="Note" required class="w-24 rounded border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                                                
                                                <textarea name="feedback" rows="4" placeholder="Commentaire de correction..." class="w-full rounded border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"><?php echo e($grade->feedback ?? ''); ?></textarea>
                                                <button type="submit" class="bg-indigo-600 text-white px-3 py-2 rounded hover:bg-indigo-700 text-xs self-start">Enregistrer la note</button>
                                            </form>
                                        <?php else: ?>
                                            <div class="text-center text-gray-400 text-sm italic">En attente de soumission</div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="py-4 text-center text-gray-500">Aucun étudiant dans cette classe.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/coach/evaluations/index.blade.php ENDPATH**/ ?>