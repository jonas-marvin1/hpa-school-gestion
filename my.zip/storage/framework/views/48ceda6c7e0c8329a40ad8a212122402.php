<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Ma progression')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-6">Mon niveau d'anglais</h3>
                    <?php if (isset($component)) { $__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.frise-niveaux','data' => ['echelle' => $echelleNiveaux,'niveau' => $niveauActuel,'anime' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frise-niveaux'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['echelle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($echelleNiveaux),'niveau' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($niveauActuel),'anime' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9)): ?>
<?php $attributes = $__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9; ?>
<?php unset($__attributesOriginalfb2fe129a6bec83a0735c1b09f0447b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9)): ?>
<?php $component = $__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9; ?>
<?php unset($__componentOriginalfb2fe129a6bec83a0735c1b09f0447b9); ?>
<?php endif; ?>
                </div>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-6">Mes indicateurs</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <?php
                            $moyenne = $averageGrade !== null ? round($averageGrade, 1) : null;
                            $jauges = [
                                ['Avancement du cursus', $courseProgress, 'bg-indigo-600', 'text-indigo-600', $sessionsDone . ' séance' . ($sessionsDone > 1 ? 's' : '') . ' sur ' . $sessionsTotal],
                                ['Devoirs rendus', $assignmentProgress, 'bg-blue-600', 'text-blue-600', $assignmentsDone . ' sur ' . $assignmentsTotal . ' demandé' . ($assignmentsTotal > 1 ? 's' : '')],
                                ['Assiduité', $attendanceRate, $attendanceRate >= 80 ? 'bg-green-600' : 'bg-red-500', $attendanceRate >= 80 ? 'text-green-600' : 'text-red-600', 'Sur ' . $totalSessions . ' cours'],
                            ];
                        ?>

                        <?php $__currentLoopData = $jauges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$titre, $valeur, $couleurBarre, $couleurTexte, $detail]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="flex items-baseline justify-between mb-2">
                                    <span class="text-sm font-medium text-gray-700"><?php echo e($titre); ?></span>
                                    <span class="text-sm font-bold <?php echo e($couleurTexte); ?>"><?php echo e($valeur); ?>%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-3">
                                    <div class="<?php echo e($couleurBarre); ?> h-3 rounded-full transition-all duration-500" style="width: <?php echo e($valeur); ?>%"></div>
                                </div>
                                <p class="text-xs text-gray-400 mt-2"><?php echo e($detail); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div>
                            <div class="flex items-baseline justify-between mb-2">
                                <span class="text-sm font-medium text-gray-700">Moyenne générale</span>
                                <span class="text-sm font-bold <?php echo e($moyenne !== null && $moyenne >= 10 ? 'text-green-600' : 'text-gray-400'); ?>">
                                    <?php echo e($moyenne !== null ? $moyenne . '/20' : '—'); ?>

                                </span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-3">
                                <div class="<?php echo e($moyenne !== null && $moyenne >= 10 ? 'bg-green-600' : 'bg-amber-500'); ?> h-3 rounded-full transition-all duration-500"
                                     style="width: <?php echo e($moyenne !== null ? min(100, $moyenne / 20 * 100) : 0); ?>%"></div>
                            </div>
                            <p class="text-xs text-gray-400 mt-2">
                                <?php echo e($moyenne !== null ? "Sur l'ensemble des devoirs notés" : 'Aucun devoir noté pour l\'instant'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide mb-4">
                        Mes notes <span class="text-gray-400 normal-case">(<?php echo e($notes->count()); ?>)</span>
                    </h3>

                    <?php if($notes->count()): ?>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse text-sm">
                                <thead>
                                    <tr>
                                        <th class="border-b py-2 px-3">Devoir</th>
                                        <th class="border-b py-2 px-3">Rendu le</th>
                                        <th class="border-b py-2 px-3 text-center">Note</th>
                                        <th class="border-b py-2 px-3">Commentaire</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="border-b py-2 px-3 font-medium"><?php echo e($n->assignment->title ?? '—'); ?></td>
                                            <td class="border-b py-2 px-3 text-gray-600"><?php echo e($n->created_at->format('d/m/Y')); ?></td>
                                            <td class="border-b py-2 px-3 text-center">
                                                <span class="font-bold <?php echo e($n->grade->score >= 10 ? 'text-green-600' : 'text-amber-600'); ?>">
                                                    <?php echo e(rtrim(rtrim(number_format($n->grade->score, 1, ',', ''), '0'), ',')); ?>/20
                                                </span>
                                            </td>
                                            <td class="border-b py-2 px-3 text-gray-700 max-w-md">
                                                <div class="whitespace-pre-wrap break-words"><?php echo e($n->grade->feedback ?: '—'); ?></div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucun devoir noté pour l'instant.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/student/espace/progression.blade.php ENDPATH**/ ?>