<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Tableau de bord Formateur')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Rémunération du mois','valeur' => number_format($kpis['remuneration_mois'], 0, ',', ' '),'unite' => 'FCFA','couleur' => 'indigo','lien' => route('coach.payments.index'),'detail' => $kpis['remuneration_due'] > 0 ? number_format($kpis['remuneration_due'], 0, ',', ' ') . ' FCFA en attente' : 'Rien en attente']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Rémunération du mois','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($kpis['remuneration_mois'], 0, ',', ' ')),'unite' => 'FCFA','couleur' => 'indigo','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.payments.index')),'detail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['remuneration_due'] > 0 ? number_format($kpis['remuneration_due'], 0, ',', ' ') . ' FCFA en attente' : 'Rien en attente')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Rapports à faire','valeur' => $kpis['rapports_en_attente'],'couleur' => $kpis['rapports_en_attente'] > 0 ? 'amber' : 'green','lien' => route('coach.reports.index'),'detail' => 'Séances passées sans rapport']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Rapports à faire','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['rapports_en_attente']),'couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['rapports_en_attente'] > 0 ? 'amber' : 'green'),'lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.reports.index')),'detail' => 'Séances passées sans rapport']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Devoirs à corriger','valeur' => $kpis['devoirs_a_corriger'],'couleur' => $kpis['devoirs_a_corriger'] > 0 ? 'amber' : 'green','lien' => route('coach.assignments.index'),'detail' => 'Rendus en attente de note']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Devoirs à corriger','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['devoirs_a_corriger']),'couleur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['devoirs_a_corriger'] > 0 ? 'amber' : 'green'),'lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.assignments.index')),'detail' => 'Rendus en attente de note']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Prochains cours','valeur' => $kpis['prochains_cours'],'couleur' => 'blue','lien' => route('coach.cours.index'),'detail' => 'Séances à venir']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Prochains cours','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['prochains_cours']),'couleur' => 'blue','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.cours.index')),'detail' => 'Séances à venir']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Rapports effectués','valeur' => $kpis['rapports_effectues'],'couleur' => 'green','lien' => route('coach.reports.index'),'detail' => 'Depuis le début']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Rapports effectués','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['rapports_effectues']),'couleur' => 'green','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.reports.index')),'detail' => 'Depuis le début']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Mes programmes','valeur' => $kpis['programmes'],'couleur' => 'purple','lien' => route('coach.programmes.index'),'detail' => 'Programmes enseignés']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Mes programmes','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['programmes']),'couleur' => 'purple','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.programmes.index')),'detail' => 'Programmes enseignés']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Mes classes actives','valeur' => $kpis['classes_actives'],'couleur' => 'purple','lien' => route('coach.classes.index'),'detail' => 'Classes rattachées']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Mes classes actives','valeur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpis['classes_actives']),'couleur' => 'purple','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('coach.classes.index')),'detail' => 'Classes rattachées']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kpi-carte','data' => ['titre' => 'Messagerie','valeur' => '—','couleur' => 'gray','lien' => route('messages.index'),'detail' => 'Consulter mes messages']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kpi-carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => 'Messagerie','valeur' => '—','couleur' => 'gray','lien' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('messages.index')),'detail' => 'Consulter mes messages']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $attributes = $__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__attributesOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80)): ?>
<?php $component = $__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80; ?>
<?php unset($__componentOriginale8f5b3b8dc52db5ac48ce5d333711d80); ?>
<?php endif; ?>
            </div>

            
            <?php if($upcomingSessions->count()): ?>
                <div class="bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="flex items-baseline justify-between mb-4">
                            <h3 class="text-gray-500 text-sm font-semibold uppercase tracking-wide">Mon prochain cours</h3>
                            <a href="<?php echo e(route('coach.cours.index')); ?>" class="text-sm text-indigo-600 hover:underline">Tout voir</a>
                        </div>

                        <?php $s = $upcomingSessions->first(); ?>
                        <div class="flex flex-wrap items-center gap-4 rounded-lg border <?php echo e($s->start_time->isToday() ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200'); ?> p-4">
                            <div class="text-center shrink-0 w-16">
                                <p class="text-2xl font-bold <?php echo e($s->start_time->isToday() ? 'text-indigo-700' : 'text-gray-900'); ?>"><?php echo e($s->start_time->format('d')); ?></p>
                                <p class="text-xs uppercase text-gray-500"><?php echo e($s->start_time->translatedFormat('M')); ?></p>
                            </div>
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-gray-900"><?php echo e($s->courseClass->name ?? '—'); ?></p>
                                <p class="text-sm text-gray-700">
                                    <?php echo e($s->start_time->translatedFormat('l')); ?>

                                    de <?php echo e($s->start_time->format('H:i')); ?> à <?php echo e($s->end_time->format('H:i')); ?>

                                    <?php if($s->start_time->isToday()): ?>
                                        <span class="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">Aujourd'hui</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <a href="<?php echo e(route('coach.sessions.show', $s)); ?>" class="text-sm text-indigo-600 hover:underline shrink-0">Détails</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\public_html\my\app\resources\views/coach/dashboard.blade.php ENDPATH**/ ?>