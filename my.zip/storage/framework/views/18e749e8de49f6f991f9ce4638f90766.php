<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(__('Mes classes')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <p class="text-sm text-gray-600 mb-5">
                        <span class="font-semibold text-gray-900"><?php echo e($classes->count()); ?></span>
                        classe<?php echo e($classes->count() > 1 ? 's' : ''); ?>.
                    </p>

                    <?php if($classes->count()): ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-lg border border-gray-200 p-4">
                                    <h3 class="font-semibold text-gray-900"><?php echo e($classe->name); ?></h3>
                                    <p class="text-xs text-gray-500 mt-0.5">
                                        <?php echo e($classe->level->program->name ?? '—'); ?>

                                        <?php if($classe->level): ?> &middot; <?php echo e($classe->level->name); ?> <?php endif; ?>
                                    </p>

                                    <dl class="mt-3 grid grid-cols-3 gap-2 text-center">
                                        <div>
                                            <dt class="text-[11px] text-gray-500">Apprenants</dt>
                                            <dd class="font-bold text-gray-900"><?php echo e($classe->nb_apprenants); ?></dd>
                                        </div>
                                        <div>
                                            <dt class="text-[11px] text-gray-500">Séances</dt>
                                            <dd class="font-bold text-gray-900"><?php echo e($classe->nb_seances); ?></dd>
                                        </div>
                                        <div>
                                            <dt class="text-[11px] text-gray-500">Effectuées</dt>
                                            <dd class="font-bold text-green-600"><?php echo e($classe->nb_effectuees); ?></dd>
                                        </div>
                                    </dl>

                                    <?php $pct = $classe->nb_seances > 0 ? (int) round($classe->nb_effectuees / $classe->nb_seances * 100) : 0; ?>
                                    <div class="mt-3 w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-purple-600 h-2 rounded-full" style="width: <?php echo e($pct); ?>%"></div>
                                    </div>
                                    <p class="text-right text-[11px] text-gray-500 mt-1"><?php echo e($pct); ?>% du cursus</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucune classe ne vous est rattachée pour l'instant.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/coach/espace/classes.blade.php ENDPATH**/ ?>