<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Messagerie - Envoyés')); ?>

            </h2>
            <a href="<?php echo e(route('messages.create')); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-sm font-medium">
                Nouveau Message
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg flex">
                
                <!-- Sidebar -->
                <div class="w-1/4 border-r border-gray-200 bg-gray-50">
                    <nav class="flex flex-col p-4 space-y-1">
                        <a href="<?php echo e(route('messages.index')); ?>" class="flex items-center px-3 py-2 text-sm font-medium rounded-md <?php echo e(request()->routeIs('messages.index') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-900 hover:bg-gray-100'); ?>">
                            Boîte de réception
                        </a>
                        <a href="<?php echo e(route('messages.sent')); ?>" class="flex items-center px-3 py-2 text-sm font-medium rounded-md <?php echo e(request()->routeIs('messages.sent') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-900 hover:bg-gray-100'); ?>">
                            Messages envoyés
                        </a>
                    </nav>
                </div>

                <!-- Content -->
                <div class="w-3/4 p-0">
                    <?php if($messages->count() > 0): ?>
                        <div class="divide-y divide-gray-200">
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('messages.show', $message)); ?>" class="block hover:bg-gray-50 bg-white">
                                    <div class="px-6 py-4 flex items-center justify-between">
                                        <div class="flex items-center space-x-3">
                                            <div class="min-w-0 flex-1">
                                                <p class="text-sm font-medium text-gray-900 truncate">
                                                    À : <?php echo e($message->receiver->name); ?>

                                                </p>
                                                <p class="text-sm text-gray-500 truncate">
                                                    <?php echo e($message->subject); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo e($message->created_at->format('d M H:i')); ?>

                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="p-4 border-t border-gray-200">
                            <?php echo e($messages->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="p-8 text-center text-gray-500">
                            Aucun message envoyé.
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/my/app/resources/views/messages/sent.blade.php ENDPATH**/ ?>