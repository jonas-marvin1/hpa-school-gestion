<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Détail du rendu')); ?>

            </h2>
            <a href="<?php echo e(route('admin.submissions.index')); ?>" class="text-sm text-indigo-600 hover:text-indigo-900">
                &larr; Retour à l'archive
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-4"><?php echo e($submission->assignment->title ?? 'Devoir supprimé'); ?></h3>
                    <dl class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 text-sm">
                        <div>
                            <dt class="font-medium text-gray-500">Apprenant</dt>
                            <dd class="text-gray-900"><?php echo e($submission->student->name ?? '—'); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Classe</dt>
                            <dd class="text-gray-900"><?php echo e($submission->assignment->courseClass->name ?? '—'); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Programme</dt>
                            <dd class="text-gray-900"><?php echo e($submission->assignment->courseClass->level->program->name ?? '—'); ?></dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-500">Formateur</dt>
                            <dd class="text-gray-900"><?php echo e($submission->assignment->coach->name ?? '—'); ?></dd>
                        </div>
                    </dl>
                </div>
            </div>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-1">Rendu de l'apprenant</h3>
                    <p class="text-xs text-gray-500 mb-4">Déposé le <?php echo e($submission->created_at->format('d/m/Y à H:i')); ?></p>

                    <?php if(filled($submission->file_path)): ?>
                        <?php
                            $ext = strtolower(pathinfo($submission->file_path, PATHINFO_EXTENSION));
                            $url = asset('storage/' . $submission->file_path);
                        ?>
                        <div class="space-y-2">
                            <?php if(in_array($ext, ['mp3', 'm4a', 'mp4', 'wav', 'ogg', 'oga', 'webm', 'weba', 'aac', '3gp', '3gpp', 'opus'])): ?>
                                <?php if (isset($component)) { $__componentOriginala0c9cb689f073f4804bbba10f772d477 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0c9cb689f073f4804bbba10f772d477 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rendu-audio','data' => ['chemin' => $submission->file_path,'auteur' => $submission->student->name ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rendu-audio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['chemin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($submission->file_path),'auteur' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($submission->student->name ?? null)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0c9cb689f073f4804bbba10f772d477)): ?>
<?php $attributes = $__attributesOriginala0c9cb689f073f4804bbba10f772d477; ?>
<?php unset($__attributesOriginala0c9cb689f073f4804bbba10f772d477); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0c9cb689f073f4804bbba10f772d477)): ?>
<?php $component = $__componentOriginala0c9cb689f073f4804bbba10f772d477; ?>
<?php unset($__componentOriginala0c9cb689f073f4804bbba10f772d477); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if(in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                                    <a href="<?php echo e($url); ?>" target="_blank" rel="noopener">
                                        <img src="<?php echo e($url); ?>" alt="Rendu de <?php echo e($submission->student->name ?? ''); ?>" class="max-h-96 rounded border border-gray-200">
                                    </a>
                                <?php elseif($ext === 'pdf'): ?>
                                    <embed src="<?php echo e($url); ?>" type="application/pdf" class="w-full h-96 rounded border border-gray-200">
                                <?php endif; ?>
                                <a href="<?php echo e($url); ?>" target="_blank" rel="noopener" class="inline-block text-indigo-600 hover:underline">
                                    Ouvrir en plein écran (<?php echo e(strtoupper($ext)); ?>)
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php elseif(filled($submission->content_text)): ?>
                        <div class="whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 text-sm leading-relaxed"><?php echo e($submission->content_text); ?></div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Aucun contenu enregistré.</p>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-4">Correction</h3>

                    <?php if($submission->grade): ?>
                        <?php
                            // Une note dont la date de modification depasse la date de
                            // creation a ete revue apres coup : on le signale plutot que
                            // de laisser croire a une correction unique.
                            $revisee = $submission->grade->updated_at->gt($submission->grade->created_at->addMinute());
                        ?>
                        <div class="flex flex-wrap items-baseline gap-x-6 gap-y-2 mb-4">
                            <span class="text-3xl font-bold <?php echo e($submission->grade->score >= 10 ? 'text-green-600' : 'text-amber-600'); ?>">
                                <?php echo e(rtrim(rtrim(number_format($submission->grade->score, 1, ',', ''), '0'), ',')); ?>/20
                            </span>
                            <span class="text-sm text-gray-500">
                                par <?php echo e($submission->grade->coach->name ?? 'formateur supprimé'); ?>

                            </span>
                        </div>

                        <?php if($submission->grade->feedback): ?>
                            <div>
                                <h4 class="text-sm font-medium text-gray-500 mb-1">Commentaire</h4>
                                <div class="whitespace-pre-wrap break-words rounded border border-gray-200 bg-gray-50 p-3 text-sm leading-relaxed"><?php echo e($submission->grade->feedback); ?></div>
                            </div>
                        <?php endif; ?>

                        <?php if($revisee): ?>
                            <p class="mt-4 text-xs text-gray-500">
                                Cette note a été revue après sa première saisie. Le détail figure dans l'historique ci-dessous.
                            </p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 italic">Ce rendu n'a pas encore été corrigé.</p>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-semibold mb-4">Historique des modifications</h3>

                    <?php
                        $libelles = [
                            'score'         => 'Note',
                            'feedback'      => 'Commentaire',
                            'content_text'  => 'Texte du rendu',
                            'file_path'     => 'Fichier joint',
                            'coach_id'      => 'Correcteur',
                            'submission_id' => 'Rendu associé',
                            'student_id'    => 'Apprenant',
                            'assignment_id' => 'Devoir',
                            'submitted_at'  => 'Date de dépôt',
                        ];
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $historique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $r = $entree['revision']; ?>
                        <div class="border-l-2 border-gray-200 pl-4 pb-5 last:pb-0 relative">
                            <span class="absolute -left-[5px] top-1.5 h-2 w-2 rounded-full bg-indigo-500"></span>
                            <div class="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                                <span class="text-sm font-medium"><?php echo e($r->libelleAction()); ?> &middot; <?php echo e($entree['objet']); ?></span>
                                <span class="text-xs text-gray-500"><?php echo e($r->created_at->format('d/m/Y à H:i')); ?></span>
                                <span class="text-xs text-gray-500">par <?php echo e($r->user->name ?? 'traitement automatique'); ?></span>
                            </div>

                            <?php if($r->action === 'updated' && filled($r->changes)): ?>
                                <ul class="mt-2 space-y-1 text-sm">
                                    <?php $__currentLoopData = $r->changes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $champ => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="text-gray-700">
                                            <span class="font-medium"><?php echo e($libelles[$champ] ?? $champ); ?></span> :
                                            <span class="line-through text-gray-400 break-words"><?php echo e(\Illuminate\Support\Str::limit($v['before'] ?? '—', 80)); ?></span>
                                            <span class="mx-1 text-gray-400">&rarr;</span>
                                            <span class="text-gray-900 break-words"><?php echo e(\Illuminate\Support\Str::limit($v['after'] ?? '—', 80)); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-500 italic">
                            Aucune modification enregistrée. Le journal ne couvre que les changements survenus depuis sa mise en service.
                        </p>
                    <?php endif; ?>
                </div>
            </div>

            <p class="text-xs text-gray-500">
                Consultation seule. La note et le commentaire ne sont modifiables que par le formateur, depuis son espace de correction.
            </p>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/admin/submissions/show.blade.php ENDPATH**/ ?>