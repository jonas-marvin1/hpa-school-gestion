<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Devoir : <?php echo e($assignment->title); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('status')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('status')); ?></span>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>- <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-between items-start mb-4 border-b pb-4">
                        <div>
                            <h3 class="text-2xl font-bold text-gray-800"><?php echo e($assignment->title); ?></h3>
                            <p class="text-sm text-gray-500 mt-1">Matière / Classe : <?php echo e($assignment->courseClass->name); ?></p>
                        </div>
                        <div class="text-right">
                            <span class="block text-sm font-semibold text-gray-600">À rendre avant le :</span>
                            <span class="block text-lg font-bold <?php echo e(\Carbon\Carbon::parse($assignment->due_date)->isPast() && !$submission ? 'text-red-600' : 'text-gray-900'); ?>">
                                <?php echo e(\Carbon\Carbon::parse($assignment->due_date)->format('d/m/Y')); ?>

                            </span>
                        </div>
                    </div>

                    <div class="prose max-w-none text-gray-700 mb-6">
                        <h4 class="font-semibold text-gray-900 mb-2">Consignes :</h4>
                        <div class="bg-gray-50 p-4 rounded-md">
                            <?php echo nl2br(e($assignment->description)); ?>

                        </div>
                        <?php if($assignment->attachment): ?>
                            <div class="mt-4">
                                <h4 class="font-semibold text-gray-900 mb-2">Fichier joint (Sujet / Exercices) :</h4>
                                <a href="<?php echo e(asset('storage/' . $assignment->attachment)); ?>" target="_blank" class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-25 transition ease-in-out duration-150">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                                    Télécharger la pièce jointe
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if($assignment->type === 'link' && $assignment->evaluation_link): ?>
                            <div class="mt-4">
                                <h4 class="font-semibold text-gray-900 mb-2">Lien d'évaluation externe :</h4>
                                <a href="<?php echo e($assignment->evaluation_link); ?>" target="_blank" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                                    Ouvrir le projet / l'évaluation
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Submission Section -->
            <?php if($submission): ?>
                <!-- Already Submitted -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border-l-4 border-green-500">
                    <div class="p-6 text-gray-900">
                        <h3 class="text-lg font-bold text-green-700 mb-2">Devoir rendu</h3>
                        <p class="text-sm text-gray-600 mb-4">Vous avez soumis ce devoir le <?php echo e(\Carbon\Carbon::parse($submission->created_at)->format('d/m/Y à H:i')); ?>.</p>
                        
                        <div class="bg-gray-50 p-4 rounded-md text-sm text-gray-700 mb-4">
                            <?php if($assignment->type === 'text'): ?>
                                <strong>Votre réponse :</strong><br>
                                <?php echo nl2br(e($submission->content_text)); ?>

                            <?php elseif($assignment->type === 'link'): ?>
                                <strong>Lien soumis :</strong><br>
                                <a href="<?php echo e($submission->content_text); ?>" target="_blank" class="text-blue-600 hover:underline break-all"><?php echo e($submission->content_text); ?></a>
                            <?php else: ?>
                                <strong>Fichier joint :</strong><br>
                                <a href="#" class="text-blue-600 hover:underline">Télécharger mon fichier</a>
                            <?php endif; ?>
                        </div>

                        <!-- Grading Section -->
                        <?php if($submission->grade): ?>
                            <div class="mt-6 border-t pt-4">
                                <h4 class="font-bold text-gray-900 mb-2">Évaluation du Formateur</h4>
                                <div class="flex items-center gap-4 mb-2">
                                    <span class="text-2xl font-bold <?php echo e($submission->grade->score >= 10 ? 'text-green-600' : 'text-red-600'); ?>"><?php echo e($submission->grade->score); ?> / 20</span>
                                </div>
                                <?php if($submission->grade->feedback): ?>
                                    <div class="text-sm italic text-gray-600 bg-yellow-50 p-3 rounded border border-yellow-200">
                                        "<?php echo e($submission->grade->feedback); ?>"
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="mt-6 border-t pt-4">
                                <p class="text-sm text-gray-500 italic">En attente d'évaluation par le formateur.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <!-- Form to Submit -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">Soumettre votre travail</h3>
                        
                        <form action="<?php echo e(route('student.assignments.submit', $assignment)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <?php if($assignment->type === 'text'): ?>
                                <div class="mb-4">
                                    <label for="content" class="block text-sm font-medium text-gray-700 mb-1">Votre réponse (Texte) *</label>
                                    <textarea name="content" id="content" rows="6" required class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"><?php echo e(old('content')); ?></textarea>
                                </div>
                            <?php elseif($assignment->type === 'link'): ?>
                                <div class="mb-4">
                                    <label for="content" class="block text-sm font-medium text-gray-700 mb-1">Votre lien (URL) *</label>
                                    <input type="url" name="content" id="content" required class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="https://..." value="<?php echo e(old('content')); ?>">
                                </div>
                            <?php elseif($assignment->type === 'file'): ?>
                                <div class="mb-4">
                                    <label for="file" class="block text-sm font-medium text-gray-700 mb-1">Fichier à joindre (PDF, DOCX, ZIP...) *</label>
                                    <input type="file" name="file" id="file" required class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                                </div>
                            <?php elseif($assignment->type === 'audio'): ?>
                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Votre enregistrement audio *</label>
                                    <?php if (isset($component)) { $__componentOriginal1ef31e4431d3dfa7a382586372a9dda6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ef31e4431d3dfa7a382586372a9dda6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.enregistreur-audio','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('enregistreur-audio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ef31e4431d3dfa7a382586372a9dda6)): ?>
<?php $attributes = $__attributesOriginal1ef31e4431d3dfa7a382586372a9dda6; ?>
<?php unset($__attributesOriginal1ef31e4431d3dfa7a382586372a9dda6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ef31e4431d3dfa7a382586372a9dda6)): ?>
<?php $component = $__componentOriginal1ef31e4431d3dfa7a382586372a9dda6; ?>
<?php unset($__componentOriginal1ef31e4431d3dfa7a382586372a9dda6); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <div class="mt-6">
                                <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md font-semibold text-sm hover:bg-indigo-700 transition" onclick="return confirm('Êtes-vous sûr de vouloir soumettre ? (Action irréversible)')">
                                    Envoyer mon devoir
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/u120571238/domains/hpacademya.com/public_html/test/app/resources/views/student/assignments/show.blade.php ENDPATH**/ ?>